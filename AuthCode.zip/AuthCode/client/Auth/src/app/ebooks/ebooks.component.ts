import { Component, OnInit } from '@angular/core';

import{ BookService } from '../book.service'

@Component({
  selector: 'app-ebooks',
  templateUrl: './ebooks.component.html',
  styleUrls: ['./ebooks.component.css']
})
export class EbooksComponent implements OnInit {
 books=[];
  constructor(private book:BookService) { }

  ngOnInit(){
    this.book.getEbooks().subscribe(
      res=>this.books=res,
      err=>console.log=err
    )
  }

}
