import { Component, OnInit } from '@angular/core';

import{ BookService } from '../book.service'
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {
  books=[];
  constructor(private book:BookService,private router:Router) { }

  ngOnInit() {
    this.book.getBooks().subscribe(
    res=>{this.books=res},
    err=>{
      
        if(err.status === 401){
        return this.router.navigate(['/login'])
        }
      
    })
  }

}
