const mongoose=require('mongoose');
var Auth=mongoose.model('Auth',{
    email:{type:String},
    password:{type:String}
})
module.exports={Auth};
