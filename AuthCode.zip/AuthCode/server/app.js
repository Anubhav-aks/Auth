const express=require('express');
const bodyParse=require('body-parser');
const cors=require('cors');

const { mongoose }=require('./db.js');
const router=require('./controller/controller.js')
const app=express();
const Auth=require('./model/Auth.js')

app.use(bodyParse.json());
// app.use(express.static(path.join(__dirname, 'public')));
app.use(cors({origin:'http://localhost:4200'}))
app.listen(3000,console.log('Server  is running at port 3000/auth'))
app.use('/auths',router)