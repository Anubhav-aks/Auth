const mongoose = require('mongoose');
const express = require('express');
const jwt = require('jsonwebtoken')
const router = express.Router();
const { Auth } = require('../model/Auth.js')

router.get('/', (req, res) => {
    Auth.find((err, doc) => {
        if (!err) {
            res.send(doc);
        }
        else {
            console.log('Error:' + JSON.stringify(err, undefined, 2))
        }
    })
})

function verifyToken(req, res, next) {
    if (!req.headers.authorization) {
        res.status(401).send('Unauthorazed Request!')
    }
    let token = req.headers.authorization.split(' ')[1]
    if (token === 'null') {
        res.status(401).send('Unauthorazed Request!')
    }
    let payload = jwt.verify(token, 'secretKey')
    if (!payload) {
        res.status(401).send('Unauthorazed Request!')
    }
    req.userId = payload.subject
    next()
}
router.post('/registration', (req, res) => {
    let userData = req.body;
    let user = new Auth(userData);
    user.save((err, doc) => {
        if (!err) {
            let payload = { subject: doc._id };
            let token = jwt.sign(payload, 'secretKey')
            res.status(200).send({ token });
        }
        else {
            console.log('Error:' + JSON.stringify(err, undefined, 2))
        }

    })
})
router.post('/login', (req, res) => {
    let userData = req.body;

    Auth.findOne({ email: userData.email }, (err, doc) => {
        if (err) {
            console.log(err);
        }
        else {
            if (!doc) {
                res.status(401).send("No Record Found!")
            }
            else {
                if (doc.password !== userData.password) {
                    res.status(401).send("Wrong Password!")
                }
                else {
                    let payload = { subject: doc._id };
                    let token = jwt.sign(payload, 'secretKey')
                    res.status(200).send({ token });
                }
            }
        }
    })
})

router.get('/books',verifyToken,(req, res) => {
    let books = [{ _id: 1, link: "https://www.amazon.in/Monk-Who-Sold-His-Ferrari-ebook/dp/B009FTAH3W/ref=as_li_ss_il?_encoding=UTF8&pd_rd_i=B009FTAH3W&pd_rd_r=3d48eeb8-d68c-49ce-8b62-e846fe8e17e7&pd_rd_w=AZdLc&pd_rd_wg=Jxw3J&pf_rd_p=5166c495-445a-420f-89dd-997dc1975336&pf_rd_r=8A1V2QTHFMKJSYCSDSZH&psc=1&refRID=8A1V2QTHFMKJSYCSDSZH&linkCode=li2&tag=anubhavak47th-21&linkId=2f7ab6cae1d6544015fc45701036255f&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B009FTAH3W&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B009FTAH3W" },
    { _id: 2, link: "https://www.amazon.in/Alchemist-Paulo-Coelho-ebook/dp/B00U6SFUSS/ref=as_li_ss_il?_encoding=UTF8&psc=1&refRID=T7T38RS74EFJ308T6YP9&linkCode=li2&tag=anubhavak47th-21&linkId=3efa9a7353034d28849dcde062f853f5&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B00U6SFUSS&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B00U6SFUSS" },
    { _id: 3, link: "https://www.amazon.in/Intelligent-Investor-Collins-Business-Essentials-ebook/dp/B000FC12C8/ref=as_li_ss_il?_encoding=UTF8&pd_rd_i=B000FC12C8&pd_rd_r=56e6bb3b-39b9-45fd-a88d-ac151aa1c6fc&pd_rd_w=XNty9&pd_rd_wg=2pCur&pf_rd_p=5166c495-445a-420f-89dd-997dc1975336&pf_rd_r=W1JH4R7DBCGAEW533YZB&psc=1&refRID=W1JH4R7DBCGAEW533YZB&linkCode=li2&tag=anubhavak47th-21&linkId=16da0191cf70e1320203f27c410c3360&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B000FC12C8&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B000FC12C8" },
    { _id: 4, link: "https://www.amazon.in/Warren-Buffett-Way-Robert-Hagstrom-ebook/dp/B00FAMMZN8/ref=as_li_ss_il?_encoding=UTF8&pd_rd_i=B00FAMMZN8&pd_rd_r=eb4b842e-237a-4cfd-95d1-c0b587e544f6&pd_rd_w=49f3M&pd_rd_wg=Uaqak&pf_rd_p=5166c495-445a-420f-89dd-997dc1975336&pf_rd_r=ACYG8NT51CJ23W90GK8C&psc=1&refRID=ACYG8NT51CJ23W90GK8C&linkCode=li2&tag=anubhavak47th-21&linkId=a427d518ef55f18aa982cf9434d8b283&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B00FAMMZN8&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B00FAMMZN8" },
    { _id: 5, link: "https://www.amazon.in/Attitude-Everything-Change-Your-Life-ebook/dp/B01MPZZLPT/ref=as_li_ss_il?_encoding=UTF8&pd_rd_i=B01MPZZLPT&pd_rd_r=9bc4cdbe-1b8b-4d88-8716-a590f8c0e768&pd_rd_w=ndP7r&pd_rd_wg=kCqB9&pf_rd_p=5166c495-445a-420f-89dd-997dc1975336&pf_rd_r=Z25HE0XEHMADF0FQNN7B&psc=1&refRID=Z25HE0XEHMADF0FQNN7B&linkCode=li2&tag=anubhavak47th-21&linkId=49d3049729c84bb0bdadf31b12d13bd8&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B01MPZZLPT&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B01MPZZLPT" },
    { _id: 6, link: "https://www.amazon.in/Art-Dealing-People-Giblin-ebook/dp/B008E7HFZY/ref=as_li_ss_il?_encoding=UTF8&pd_rd_i=B008E7HFZY&pd_rd_r=82bbc529-c8a7-4055-a03f-780df3358f99&pd_rd_w=phN8R&pd_rd_wg=1JFq4&pf_rd_p=5166c495-445a-420f-89dd-997dc1975336&pf_rd_r=CA3FN3XDH90KGZ77Q439&psc=1&refRID=CA3FN3XDH90KGZ77Q439&linkCode=li2&tag=anubhavak47th-21&linkId=c142d059d170230a241e5fe36656aeba&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B008E7HFZY&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B008E7HFZY" },
    { _id: 7, link: "https://www.amazon.in/Who-Will-Cry-When-You-ebook/dp/B008PQASJ4/ref=as_li_ss_il?_encoding=UTF8&pd_rd_i=B008PQASJ4&pd_rd_r=9bc4cdbe-1b8b-4d88-8716-a590f8c0e768&pd_rd_w=ndP7r&pd_rd_wg=kCqB9&pf_rd_p=5166c495-445a-420f-89dd-997dc1975336&pf_rd_r=Z25HE0XEHMADF0FQNN7B&psc=1&refRID=Z25HE0XEHMADF0FQNN7B&linkCode=li2&tag=anubhavak47th-21&linkId=dcaaef462cf4633ca7eb949de7f27732&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B008PQASJ4&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B008PQASJ4" },
    { _id: 8, link: "https://www.amazon.in/Eleven-Minutes-Paulo-Coelho-ebook/dp/B004XYX4WU/ref=as_li_ss_il?_encoding=UTF8&pd_rd_i=B004XYX4WU&pd_rd_r=3d48eeb8-d68c-49ce-8b62-e846fe8e17e7&pd_rd_w=AZdLc&pd_rd_wg=Jxw3J&pf_rd_p=5166c495-445a-420f-89dd-997dc1975336&pf_rd_r=8A1V2QTHFMKJSYCSDSZH&psc=1&refRID=8A1V2QTHFMKJSYCSDSZH&linkCode=li2&tag=anubhavak47th-21&linkId=624ab9a773b8f9b0013adcfbaf115917&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B004XYX4WU&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B004XYX4WU" },
    { _id: 9, link: "https://www.amazon.in/Ikigai-Japanese-secret-long-happy-ebook/dp/B073D36KNM/ref=as_li_ss_il?_encoding=UTF8&psc=1&refRID=T7T38RS74EFJ308T6YP9&linkCode=li2&tag=anubhavak47th-21&linkId=9bd586074c492bff1d1fa6575208bdea&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B004XOZ9DC&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B004XOZ9DC" },
    { _id: 10, link: "https://www.amazon.in/Harry-Potter-Philosophers-Stone-Rowling-ebook/dp/B019PIOJYU/ref=as_li_ss_il?_encoding=UTF8&psc=1&refRID=T7T38RS74EFJ308T6YP9&linkCode=li2&tag=anubhavak47th-21&linkId=8c884dbffb1c6db53fd130ddf8a764af&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B073D36KNM&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B073D36KNM" },
    { _id: 11, link: "https://www.amazon.in/Vikram-Betaal-Illustrated-Maple-Press-ebook/dp/B01JS7JLBY/ref=as_li_ss_il?_encoding=UTF8&psc=1&refRID=T7T38RS74EFJ308T6YP9&linkCode=li2&tag=anubhavak47th-21&linkId=2088446562ddf63f9eb04e3902af0c35&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B019PIOJYU&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B019PIOJYU" },
    { _id: 12, link: "https://www.amazon.in/Happy-Mind-Simple-Happier-Starting-ebook/dp/B076QDYL9X/ref=as_li_ss_il?_encoding=UTF8&psc=1&refRID=T7T38RS74EFJ308T6YP9&linkCode=li2&tag=anubhavak47th-21&linkId=2c5a4ddccafb62b6f01dc7dc427c7f96&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B01JS7JLBY&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B01JS7JLBY" },
    { _id: 13, link: "https://www.amazon.in/THINK-STRAIGHT-Change-Your-Thoughts-ebook/dp/B077NJWFR3/ref=as_li_ss_il?_encoding=UTF8&psc=1&refRID=T7T38RS74EFJ308T6YP9&linkCode=li2&tag=anubhavak47th-21&linkId=e7abd2b1e45b1daac6c36c47dc55b995&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B076QDYL9X&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B076QDYL9X" },
    { _id: 14, link: "https://www.amazon.in/Mans-Search-Meaning-classic-Holocaust-ebook/dp/B00EKOC0HI/ref=as_li_ss_il?_encoding=UTF8&psc=1&refRID=T7T38RS74EFJ308T6YP9&linkCode=li2&tag=anubhavak47th-21&linkId=afc197d3f5fc52d120a883e610ad6b9d&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B077NJWFR3&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B077NJWFR3" },
    { _id: 15, link: "https://www.amazon.in/Spies-Lies-Tape-Spy-Military-Political-Thriller-based-ebook/dp/B07Z38DYYH/ref=as_li_ss_il?_encoding=UTF8&psc=1&refRID=T7T38RS74EFJ308T6YP9&linkCode=li2&tag=anubhavak47th-21&linkId=eca9bb2471fecebad55c2e43e3a03a51&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B00EKOC0HI&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B00EKOC0HI" },
    { _id: 16, link: "https://www.amazon.in/Harry-Potter-Chamber-Secrets-Rowling-ebook/dp/B019PIOJY0/ref=as_li_ss_il?_encoding=UTF8&psc=1&refRID=ZC26CB8XBE9FAJAVZ49Y&linkCode=li2&tag=anubhavak47th-21&linkId=e1d80969ec36b39e581e1017ae53029e&language=en_IN",
      src:"//ws-in.amazon-adsystem.com/widgets/q?_encoding=UTF8&ASIN=B07Z38DYYH&Format=_SL160_&ID=AsinImage&MarketPlace=IN&ServiceVersion=20070822&WS=1&tag=anubhavak47th-21&language=en_IN",
      src1:"https://ir-in.amazon-adsystem.com/e/ir?t=anubhavak47th-21&language=en_IN&l=li2&o=31&a=B07Z38DYYH" }]

    res.json(books);
})
router.get('/eBooks',(req, res) => {
    let ebooks = [{ _id: 1, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B07XF3J8BH&asins=B07XF3J8BH&linkId=2ec046f81b6e45f8011fbf4f6840d4cf&show_border=true&link_opens_in_new_window=true" },
    { _id: 2, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B07XGC9LPS&asins=B07XGC9LPS&linkId=3c008d0d89810790f4ae880462f58e84&show_border=true&link_opens_in_new_window=true" },
    { _id: 3, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B0821GG9R9&asins=B0821GG9R9&linkId=3c0ac10e644abb40dbdebfaf755b28cd&show_border=true&link_opens_in_new_window=true" },
    { _id: 4, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B0828811WR&asins=B0828811WR&linkId=8712497e0a56d4e13878b0a115eae0e3&show_border=true&link_opens_in_new_window=true" },
    { _id: 5, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B07TMM32H8&asins=B07TMM32H8&linkId=69c7e1e7d38bb7acd1bf32617d22211a&show_border=true&link_opens_in_new_window=true" },
    { _id: 6, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B07MXP1VQG&asins=B07MXP1VQG&linkId=4a484a288dae307ce8870856647ff803&show_border=true&link_opens_in_new_window=true" },
    { _id: 7, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B07VT4PHRM&asins=B07VT4PHRM&linkId=3505e3f0eed0d9d0b911dcbbb9ba0237&show_border=true&link_opens_in_new_window=true" },
    { _id: 8, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B07YXWZZ4M&asins=B07YXWZZ4M&linkId=3c914c0fcdb3d777dc71e66fd46972c1&show_border=true&link_opens_in_new_window=true" },
    { _id: 9, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B081TC4RBY&asins=B081TC4RBY&linkId=048f5b6fd51b11ec26e275bcaf1c4594&show_border=true&link_opens_in_new_window=true" },
    { _id: 10, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B07Z5BMZR9&asins=B07Z5BMZR9&linkId=18b7d7f8e0ef056b11875c673eb6383e&show_border=true&link_opens_in_new_window=true" },
    { _id: 11, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B085CK3FJY&asins=B085CK3FJY&linkId=e3d322d0e01dc6af391966780515bbca&show_border=true&link_opens_in_new_window=true" },
    { _id: 12, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B086J4L22G&asins=B086J4L22G&linkId=1f4b25534e21a4d322cee2dd8de7e462&show_border=true&link_opens_in_new_window=true" },
    { _id: 13, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B082Z5D4NF&asins=B082Z5D4NF&linkId=0b8ae72b2b0ed1de4185dfd11aad2a8d&show_border=true&link_opens_in_new_window=true" },
    { _id: 14, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B085GLGT7V&asins=B085GLGT7V&linkId=ebe0d159a3128eae546e32463ce21aa7&show_border=true&link_opens_in_new_window=true" },
    { _id: 15, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B085NQGPKY&asins=B085NQGPKY&linkId=ef444a7c3814952d37a8a2ceb8817e7d&show_border=true&link_opens_in_new_window=true" },
    { _id: 16, link: "//ws-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&OneJS=1&Operation=GetAdHtml&MarketPlace=IN&source=ss&ref=as_ss_li_til&ad_type=product_link&tracking_id=anubhavak47th-21&language=en_IN&marketplace=amazon&region=IN&placement=B082R8CK84&asins=B082R8CK84&linkId=d7df4bc9bc13618bb54b88a2e8338fe5&show_border=true&link_opens_in_new_window=true" }]
    res.json(ebooks);
})
module.exports = router;