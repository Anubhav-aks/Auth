const mongoose=require('mongoose');
const url='mongodb://localhost:27017/AuthDB'

mongoose.connect(url,function(err)
{
if(err) throw err;
console.log('MongoDB is connected')
}
)
module.exports=mongoose;